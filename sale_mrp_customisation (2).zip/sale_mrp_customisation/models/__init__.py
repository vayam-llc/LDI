# -*- coding: utf-8 -*-

from . import product
from . import mrp_workorder
from . import mrp_product_produce
from . import stock_quant
from . import stock
from . import stock_production_lot
from . import stock_picking
